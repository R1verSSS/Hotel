export interface Room {
  id: string;
  title: string;
  description: string;
  price: number;
  capacity: number;
  area: number;
  image: string;
  images: string[];
  amenities: {
    icon: string;
    name: string;
  }[];
}

export const rooms: Room[] = [
  {
    id: '1',
    title: 'Стандарт',
    description: 'Уютный номер с удобной кроватью и современной мебелью',
    price: 2500,
    capacity: 2,
    area: 25,
    image: 'https://images.unsplash.com/photo-1611892440504-42a792e24d32?w=800&h=600&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1611892440504-42a792e24d32?w=800&h=600&fit=crop',
      'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?w=800&h=600&fit=crop',
      'https://images.unsplash.com/photo-1566665797739-1674de7a421a?w=800&h=600&fit=crop',
    ],
    amenities: [
      { icon: 'Wifi', name: 'Wi-Fi' },
      { icon: 'Tv', name: 'Телевизор' },
      { icon: 'Wind', name: 'Кондиционер' },
      { icon: 'Coffee', name: 'Мини-бар' },
    ],
  },
  {
    id: '2',
    title: 'Люкс',
    description: 'Просторный номер с современной мебелью и панорамным видом',
    price: 5000,
    capacity: 2,
    area: 35,
    image: 'https://images.unsplash.com/photo-1590490360182-c33d57733427?w=800&h=600&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1590490360182-c33d57733427?w=800&h=600&fit=crop',
      'https://images.unsplash.com/photo-1591088398332-8a7791972843?w=800&h=600&fit=crop',
      'https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?w=800&h=600&fit=crop',
    ],
    amenities: [
      { icon: 'Wifi', name: 'Wi-Fi' },
      { icon: 'Tv', name: 'Телевизор' },
      { icon: 'Wind', name: 'Кондиционер' },
      { icon: 'Coffee', name: 'Мини-бар' },
    ],
  },
  {
    id: '3',
    title: 'Семейный',
    description: 'Идеальный номер для семейного отдыха с просторной планировкой',
    price: 3500,
    capacity: 4,
    area: 40,
    image: 'https://images.unsplash.com/photo-1598928506311-c55ded91a20c?w=800&h=600&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1598928506311-c55ded91a20c?w=800&h=600&fit=crop',
      'https://images.unsplash.com/photo-1560185893-a55cbc8c57e8?w=800&h=600&fit=crop',
      'https://images.unsplash.com/photo-1631049307264-da0ec9d70304?w=800&h=600&fit=crop',
    ],
    amenities: [
      { icon: 'Wifi', name: 'Wi-Fi' },
      { icon: 'Tv', name: 'Телевизор' },
      { icon: 'Wind', name: 'Кондиционер' },
      { icon: 'Coffee', name: 'Мини-бар' },
    ],
  },
  {
    id: '4',
    title: 'Делюкс',
    description: 'Роскошный номер премиум-класса с эксклюзивными удобствами',
    price: 7500,
    capacity: 2,
    area: 45,
    image: 'https://images.unsplash.com/photo-1578683010236-d716f9a3f461?w=800&h=600&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1578683010236-d716f9a3f461?w=800&h=600&fit=crop',
      'https://images.unsplash.com/photo-1616594039964-ae9021a400a0?w=800&h=600&fit=crop',
      'https://images.unsplash.com/photo-1595526114035-0d45ed16cfbf?w=800&h=600&fit=crop',
    ],
    amenities: [
      { icon: 'Wifi', name: 'Wi-Fi' },
      { icon: 'Tv', name: 'Телевизор' },
      { icon: 'Wind', name: 'Кондиционер' },
      { icon: 'Coffee', name: 'Мини-бар' },
    ],
  },
];
