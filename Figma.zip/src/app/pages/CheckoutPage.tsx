import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router';
import { Button } from '../components/atoms/Button';
import { Input } from '../components/atoms/Input';
import { Icons } from '../components/atoms/Icons';

interface CartItem {
  room: {
    id: string;
    title: string;
    price: number;
  };
  checkIn: string;
  checkOut: string;
  guests: number;
}

export function CheckoutPage() {
  const navigate = useNavigate();
  const [cart, setCart] = useState<CartItem[]>([]);
  const [formData, setFormData] = useState({
    fullName: '',
    passport: '',
    phone: '',
    email: '',
  });
  const [paymentMethod, setPaymentMethod] = useState('online');

  useEffect(() => {
    const savedCart = localStorage.getItem('cart');
    if (savedCart) {
      setCart(JSON.parse(savedCart));
    } else {
      navigate('/cart');
    }
  }, [navigate]);

  const calculateNights = (checkIn: string, checkOut: string) => {
    const start = new Date(checkIn);
    const end = new Date(checkOut);
    const diffTime = Math.abs(end.getTime() - start.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  const calculateTotal = () => {
    return cart.reduce((total, item) => {
      const nights = calculateNights(item.checkIn, item.checkOut);
      return total + item.room.price * nights;
    }, 0);
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('ru-RU', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.fullName || !formData.passport || !formData.phone || !formData.email) {
      alert('Пожалуйста, заполните все поля');
      return;
    }

    alert('Бронирование успешно оформлено! Мы свяжемся с вами в ближайшее время.');
    localStorage.removeItem('cart');
    navigate('/');
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  if (cart.length === 0) {
    return null;
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="mb-8">Оформление бронирования</h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="bg-card rounded-lg shadow-md p-6">
              <h3 className="mb-4">Информация о госте</h3>
              <div className="space-y-4">
                <Input
                  label="ФИО"
                  type="text"
                  placeholder="Иванов Иван Иванович"
                  value={formData.fullName}
                  onChange={(e) => handleInputChange('fullName', e.target.value)}
                  required
                />
                <Input
                  label="Паспортные данные"
                  type="text"
                  placeholder="1234 567890"
                  value={formData.passport}
                  onChange={(e) => handleInputChange('passport', e.target.value)}
                  required
                />
                <Input
                  label="Телефон"
                  type="tel"
                  placeholder="+7 (900) 123-45-67"
                  value={formData.phone}
                  onChange={(e) => handleInputChange('phone', e.target.value)}
                  required
                />
                <Input
                  label="Email"
                  type="email"
                  placeholder="example@mail.ru"
                  value={formData.email}
                  onChange={(e) => handleInputChange('email', e.target.value)}
                  required
                />
              </div>
            </div>

            <div className="bg-card rounded-lg shadow-md p-6">
              <h3 className="mb-4">Способ оплаты</h3>
              <div className="space-y-3">
                <label className="flex items-center gap-3 p-4 border border-border rounded-lg cursor-pointer hover:bg-muted/50 transition-colors">
                  <input
                    type="radio"
                    name="payment"
                    value="online"
                    checked={paymentMethod === 'online'}
                    onChange={() => setPaymentMethod('online')}
                    className="w-4 h-4 text-primary"
                  />
                  <div>
                    <p className="font-medium">Оплата онлайн</p>
                    <p className="text-sm text-muted-foreground">
                      Оплатите картой через безопасное соединение
                    </p>
                  </div>
                </label>

                <label className="flex items-center gap-3 p-4 border border-border rounded-lg cursor-pointer hover:bg-muted/50 transition-colors">
                  <input
                    type="radio"
                    name="payment"
                    value="hotel"
                    checked={paymentMethod === 'hotel'}
                    onChange={() => setPaymentMethod('hotel')}
                    className="w-4 h-4 text-primary"
                  />
                  <div>
                    <p className="font-medium">Оплата в отеле</p>
                    <p className="text-sm text-muted-foreground">
                      Оплатите при заселении наличными или картой
                    </p>
                  </div>
                </label>
              </div>
            </div>

            <Button type="submit" className="w-full">
              Подтвердить бронирование
            </Button>
          </form>
        </div>

        <div className="lg:col-span-1">
          <div className="bg-card rounded-lg shadow-md p-6 sticky top-24">
            <h3 className="mb-4">Детали бронирования</h3>

            <div className="space-y-4 mb-6">
              {cart.map((item, index) => {
                const nights = calculateNights(item.checkIn, item.checkOut);
                const total = item.room.price * nights;

                return (
                  <div key={index} className="pb-4 border-b border-border last:border-0">
                    <p className="font-medium mb-2">{item.room.title}</p>
                    <div className="space-y-1 text-sm text-muted-foreground">
                      <div className="flex items-center gap-2">
                        <Icons.Calendar size={14} />
                        <span>
                          {formatDate(item.checkIn)} - {formatDate(item.checkOut)}
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Icons.Users size={14} />
                        <span>{item.guests} гостя</span>
                      </div>
                      <div>
                        <span>
                          {nights} {nights === 1 ? 'ночь' : nights < 5 ? 'ночи' : 'ночей'} × {item.room.price} ₽
                        </span>
                      </div>
                      <p className="font-semibold text-foreground">{total} ₽</p>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="border-t border-border pt-4">
              <div className="flex justify-between items-center">
                <span className="text-lg font-semibold">Итого:</span>
                <span className="text-2xl font-semibold text-primary">{calculateTotal()} ₽</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
