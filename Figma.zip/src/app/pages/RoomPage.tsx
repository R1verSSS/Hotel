import { useState } from 'react';
import { useParams, useNavigate } from 'react-router';
import { Button } from '../components/atoms/Button';
import { Input } from '../components/atoms/Input';
import { Select } from '../components/atoms/Select';
import { Icons } from '../components/atoms/Icons';
import { RoomGrid } from '../components/organisms/RoomGrid';
import { rooms } from '../data/rooms';

export function RoomPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const room = rooms.find((r) => r.id === id);
  const [mainImage, setMainImage] = useState(0);
  const [checkIn, setCheckIn] = useState('');
  const [checkOut, setCheckOut] = useState('');
  const [guests, setGuests] = useState('1');

  if (!room) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <h2>Номер не найден</h2>
        <Button onClick={() => navigate('/')} className="mt-4">
          Вернуться на главную
        </Button>
      </div>
    );
  }

  const recommendedRooms = rooms.filter((r) => r.id !== id).slice(0, 3);

  const handleAddToCart = () => {
    if (!checkIn || !checkOut) {
      alert('Пожалуйста, выберите даты заезда и выезда');
      return;
    }

    const booking = {
      room,
      checkIn,
      checkOut,
      guests: parseInt(guests),
    };

    const existingCart = localStorage.getItem('cart');
    const cart = existingCart ? JSON.parse(existingCart) : [];
    cart.push(booking);
    localStorage.setItem('cart', JSON.stringify(cart));

    navigate('/cart');
  };

  const iconComponents: Record<string, any> = {
    Wifi: Icons.Wifi,
    Tv: Icons.Tv,
    Wind: Icons.Wind,
    Coffee: Icons.Coffee,
  };

  return (
    <div className="py-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
          <div>
            <img
              src={room.images[mainImage]}
              alt={room.title}
              className="w-full h-96 object-cover rounded-lg mb-4"
            />
            <div className="grid grid-cols-3 gap-4">
              {room.images.map((image, index) => (
                <img
                  key={index}
                  src={image}
                  alt={`${room.title} ${index + 1}`}
                  className={`w-full h-24 object-cover rounded-lg cursor-pointer transition-all ${
                    mainImage === index ? 'ring-2 ring-primary' : 'opacity-70 hover:opacity-100'
                  }`}
                  onClick={() => setMainImage(index)}
                />
              ))}
            </div>
          </div>

          <div>
            <h1 className="mb-4">{room.title}</h1>
            <p className="text-lg text-muted-foreground mb-6">{room.description}</p>

            <div className="bg-card p-6 rounded-lg shadow-md mb-6">
              <div className="mb-4">
                <p className="text-3xl font-semibold text-primary">{room.price} ₽</p>
                <p className="text-muted-foreground">за ночь</p>
              </div>

              <div className="grid grid-cols-2 gap-4 mb-4">
                <div className="flex items-center gap-2">
                  <Icons.Users size={20} className="text-primary" />
                  <div>
                    <p className="text-sm text-muted-foreground">Вместимость</p>
                    <p className="font-semibold">{room.capacity} гостя</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Icons.Maximize size={20} className="text-primary" />
                  <div>
                    <p className="text-sm text-muted-foreground">Площадь</p>
                    <p className="font-semibold">{room.area} м²</p>
                  </div>
                </div>
              </div>

              <div className="border-t border-border pt-4 mb-4">
                <h4 className="mb-3">Удобства:</h4>
                <div className="grid grid-cols-2 gap-3">
                  {room.amenities.map((amenity, index) => {
                    const IconComponent = iconComponents[amenity.icon];
                    return (
                      <div key={index} className="flex items-center gap-2">
                        {IconComponent && <IconComponent size={18} className="text-primary" />}
                        <span className="text-sm">{amenity.name}</span>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            <div className="bg-card p-6 rounded-lg shadow-md">
              <h3 className="mb-4">Забронировать номер</h3>
              <div className="space-y-4">
                <Input
                  type="date"
                  label="Заезд"
                  value={checkIn}
                  onChange={(e) => setCheckIn(e.target.value)}
                  min={new Date().toISOString().split('T')[0]}
                />
                <Input
                  type="date"
                  label="Выезд"
                  value={checkOut}
                  onChange={(e) => setCheckOut(e.target.value)}
                  min={checkIn || new Date().toISOString().split('T')[0]}
                />
                <Select
                  label="Количество гостей"
                  value={guests}
                  onChange={(e) => setGuests(e.target.value)}
                  options={Array.from({ length: room.capacity }, (_, i) => ({
                    value: String(i + 1),
                    label: `${i + 1} ${i === 0 ? 'гость' : 'гостя'}`,
                  }))}
                />
                <Button onClick={handleAddToCart} className="w-full">
                  Добавить в бронь
                </Button>
              </div>
            </div>
          </div>
        </div>

        {recommendedRooms.length > 0 && (
          <div>
            <h2 className="mb-8">Похожие номера</h2>
            <RoomGrid rooms={recommendedRooms} />
          </div>
        )}
      </div>
    </div>
  );
}
