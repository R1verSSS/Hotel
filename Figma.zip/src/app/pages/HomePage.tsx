import { Link } from 'react-router';
import { Button } from '../components/atoms/Button';
import { RoomGrid } from '../components/organisms/RoomGrid';
import { FeatureCard } from '../components/molecules/FeatureCard';
import { Icons } from '../components/atoms/Icons';
import { rooms } from '../data/rooms';

export function HomePage() {
  return (
    <div>
      <section className="relative bg-gradient-to-r from-primary/10 to-secondary/10 py-20 md:py-32">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl">
            <h1 className="mb-4">Добро пожаловать в наш отель</h1>
            <p className="text-xl text-muted-foreground mb-8">
              Комфортный отдых по доступным ценам
            </p>
            <Link to="/cart">
              <Button variant="primary" className="text-lg px-8 py-4">
                Забронировать номер
              </Button>
            </Link>
          </div>
        </div>
      </section>

      <section id="rooms" className="py-16 bg-background">
        <div className="container mx-auto px-4">
          <h2 className="text-center mb-12">Наши номера</h2>
          <RoomGrid rooms={rooms} />
        </div>
      </section>

      <section id="services" className="py-16 bg-card">
        <div className="container mx-auto px-4">
          <h2 className="text-center mb-12">Наши услуги</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <FeatureCard
              icon={<Icons.Wifi size={32} />}
              title="Бесплатный Wi-Fi"
              description="Высокоскоростной интернет во всех номерах"
            />
            <FeatureCard
              icon={<Icons.Coffee size={32} />}
              title="Завтрак включен"
              description="Разнообразный завтрак каждое утро"
            />
            <FeatureCard
              icon={<Icons.MapPin size={32} />}
              title="Парковка"
              description="Бесплатная охраняемая парковка"
            />
            <FeatureCard
              icon={<Icons.Clock size={32} />}
              title="Круглосуточный ресепшн"
              description="Мы всегда готовы вам помочь"
            />
          </div>
        </div>
      </section>

      <section id="about" className="py-16 bg-background">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="mb-6">О нас</h2>
            <p className="text-lg text-muted-foreground mb-4">
              Наш отель расположен в самом сердце Казани, предлагая комфортабельные номера
              и высокий уровень сервиса. Мы заботимся о каждом госте и стремимся сделать
              ваше пребывание незабываемым.
            </p>
            <p className="text-lg text-muted-foreground">
              Современные номера, удобное расположение и доступные цены - все это делает
              наш отель идеальным выбором для вашего визита в Казань.
            </p>
          </div>
        </div>
      </section>

      <section id="contacts" className="py-16 bg-card">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="mb-8">Контакты</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="flex flex-col items-center">
                <Icons.MapPin size={32} className="text-primary mb-3" />
                <h4 className="mb-2">Адрес</h4>
                <p className="text-muted-foreground">г. Казань, ул. Ленина 10</p>
              </div>
              <div className="flex flex-col items-center">
                <Icons.Phone size={32} className="text-primary mb-3" />
                <h4 className="mb-2">Телефон</h4>
                <p className="text-muted-foreground">+7 (843) 123-45-67</p>
              </div>
              <div className="flex flex-col items-center">
                <Icons.Mail size={32} className="text-primary mb-3" />
                <h4 className="mb-2">Email</h4>
                <p className="text-muted-foreground">info@hotel.ru</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
