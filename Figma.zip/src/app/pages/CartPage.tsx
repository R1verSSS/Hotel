import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router';
import { Button } from '../components/atoms/Button';
import { Icons } from '../components/atoms/Icons';

interface CartItem {
  room: {
    id: string;
    title: string;
    price: number;
    image: string;
  };
  checkIn: string;
  checkOut: string;
  guests: number;
}

export function CartPage() {
  const [cart, setCart] = useState<CartItem[]>([]);
  const navigate = useNavigate();

  useEffect(() => {
    const savedCart = localStorage.getItem('cart');
    if (savedCart) {
      setCart(JSON.parse(savedCart));
    }
  }, []);

  const removeFromCart = (index: number) => {
    const newCart = cart.filter((_, i) => i !== index);
    setCart(newCart);
    localStorage.setItem('cart', JSON.stringify(newCart));
  };

  const calculateNights = (checkIn: string, checkOut: string) => {
    const start = new Date(checkIn);
    const end = new Date(checkOut);
    const diffTime = Math.abs(end.getTime() - start.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  const calculateTotal = () => {
    return cart.reduce((total, item) => {
      const nights = calculateNights(item.checkIn, item.checkOut);
      return total + item.room.price * nights;
    }, 0);
  };

  const handleCheckout = () => {
    if (cart.length === 0) {
      alert('Ваша корзина пуста');
      return;
    }
    navigate('/checkout');
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('ru-RU', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
    });
  };

  if (cart.length === 0) {
    return (
      <div className="container mx-auto px-4 py-16">
        <div className="max-w-2xl mx-auto text-center">
          <h2 className="mb-4">Ваша корзина пуста</h2>
          <p className="text-muted-foreground mb-8">
            Добавьте номера в корзину, чтобы продолжить бронирование
          </p>
          <Link to="/">
            <Button variant="primary">Выбрать номер</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="mb-8">Ваша бронь</h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-4">
          {cart.map((item, index) => {
            const nights = calculateNights(item.checkIn, item.checkOut);
            const total = item.room.price * nights;

            return (
              <div key={index} className="bg-card rounded-lg shadow-md p-6">
                <div className="flex flex-col md:flex-row gap-4">
                  <img
                    src={item.room.image}
                    alt={item.room.title}
                    className="w-full md:w-32 h-32 object-cover rounded-lg"
                  />

                  <div className="flex-1">
                    <div className="flex justify-between items-start mb-2">
                      <h3>{item.room.title}</h3>
                      <button
                        onClick={() => removeFromCart(index)}
                        className="text-destructive hover:text-destructive/80 transition-colors"
                      >
                        <Icons.Trash2 size={20} />
                      </button>
                    </div>

                    <div className="space-y-2 text-sm text-muted-foreground">
                      <div className="flex items-center gap-2">
                        <Icons.Calendar size={16} />
                        <span>
                          {formatDate(item.checkIn)} - {formatDate(item.checkOut)}
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Icons.Users size={16} />
                        <span>{item.guests} гостя</span>
                      </div>
                      <div>
                        <span>{nights} {nights === 1 ? 'ночь' : nights < 5 ? 'ночи' : 'ночей'}</span>
                      </div>
                    </div>

                    <div className="mt-4 flex justify-between items-center">
                      <div>
                        <p className="text-sm text-muted-foreground">
                          {item.room.price} ₽ × {nights} {nights === 1 ? 'ночь' : nights < 5 ? 'ночи' : 'ночей'}
                        </p>
                        <p className="text-xl font-semibold text-primary">{total} ₽</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        <div className="lg:col-span-1">
          <div className="bg-card rounded-lg shadow-md p-6 sticky top-24">
            <h3 className="mb-4">Итого</h3>

            <div className="space-y-3 mb-6">
              {cart.map((item, index) => {
                const nights = calculateNights(item.checkIn, item.checkOut);
                const total = item.room.price * nights;
                return (
                  <div key={index} className="flex justify-between text-sm">
                    <span className="text-muted-foreground">{item.room.title}</span>
                    <span>{total} ₽</span>
                  </div>
                );
              })}
            </div>

            <div className="border-t border-border pt-4 mb-6">
              <div className="flex justify-between items-center">
                <span className="text-lg font-semibold">Итого:</span>
                <span className="text-2xl font-semibold text-primary">{calculateTotal()} ₽</span>
              </div>
            </div>

            <Button onClick={handleCheckout} className="w-full">
              Оформить бронирование
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
