import {
  Wifi,
  Tv,
  Wind,
  Coffee,
  Phone,
  Mail,
  Calendar,
  Trash2,
  Users,
  Maximize,
  MapPin,
  Clock,
  CheckCircle,
  Menu,
  X
} from 'lucide-react';

export const Icons = {
  Wifi,
  Tv,
  Wind,
  Coffee,
  Phone,
  Mail,
  Calendar,
  Trash2,
  Users,
  Maximize,
  MapPin,
  Clock,
  CheckCircle,
  Menu,
  X
};
