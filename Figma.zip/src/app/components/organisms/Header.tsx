import { useState } from 'react';
import { Link } from 'react-router';
import { NavMenu } from '../molecules/NavMenu';
import { Icons } from '../atoms/Icons';

export function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="bg-card shadow-sm sticky top-0 z-50">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <Link to="/" className="flex items-center">
            <h2 className="text-primary">Отель</h2>
          </Link>

          <NavMenu />

          <button
            className="md:hidden p-2"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? (
              <Icons.X size={24} className="text-foreground" />
            ) : (
              <Icons.Menu size={24} className="text-foreground" />
            )}
          </button>
        </div>

        {mobileMenuOpen && (
          <div className="md:hidden pt-4 pb-2 border-t border-border mt-4">
            <NavMenu mobile onClose={() => setMobileMenuOpen(false)} />
            <Link to="/cart" className="mt-4 block">
              <button className="w-full px-5 py-2 bg-secondary text-secondary-foreground rounded-lg hover:opacity-90 transition-all">
                Бронирование
              </button>
            </Link>
          </div>
        )}
      </div>
    </header>
  );
}
