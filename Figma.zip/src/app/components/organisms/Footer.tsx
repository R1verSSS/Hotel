import { Icons } from '../atoms/Icons';

export function Footer() {
  return (
    <footer className="bg-card border-t border-border mt-auto">
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="mb-4">Отель</h3>
            <p className="text-muted-foreground">
              Комфортный отдых по доступным ценам
            </p>
          </div>

          <div>
            <h4 className="mb-4">Контакты</h4>
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-muted-foreground">
                <Icons.MapPin size={18} />
                <span className="text-sm">г. Казань, ул. Ленина 10</span>
              </div>
              <div className="flex items-center gap-2 text-muted-foreground">
                <Icons.Phone size={18} />
                <span className="text-sm">+7 (843) 123-45-67</span>
              </div>
              <div className="flex items-center gap-2 text-muted-foreground">
                <Icons.Mail size={18} />
                <span className="text-sm">info@hotel.ru</span>
              </div>
            </div>
          </div>

          <div>
            <h4 className="mb-4">Режим работы</h4>
            <div className="flex items-center gap-2 text-muted-foreground">
              <Icons.Clock size={18} />
              <span className="text-sm">Круглосуточный ресепшн</span>
            </div>
          </div>
        </div>

        <div className="border-t border-border mt-8 pt-6 text-center text-sm text-muted-foreground">
          © 2026 Отель. Все права защищены.
        </div>
      </div>
    </footer>
  );
}
