import { Link, useLocation } from 'react-router';

const navLinks = [
  { label: 'Номера', href: '#rooms' },
  { label: 'Услуги', href: '#services' },
  { label: 'О нас', href: '#about' },
  { label: 'Контакты', href: '#contacts' },
];

export function NavMenu({ mobile = false, onClose }: { mobile?: boolean; onClose?: () => void }) {
  const location = useLocation();

  const handleClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    if (location.pathname === '/' && href.startsWith('#')) {
      e.preventDefault();
      const element = document.querySelector(href);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
      if (onClose) onClose();
    }
  };

  return (
    <nav className={mobile ? 'flex flex-col gap-4' : 'hidden md:flex items-center gap-6'}>
      {navLinks.map((link) => (
        <a
          key={link.href}
          href={link.href}
          onClick={(e) => handleClick(e, link.href)}
          className="text-foreground hover:text-primary transition-colors"
        >
          {link.label}
        </a>
      ))}
      {!mobile && (
        <Link to="/cart">
          <button className="px-5 py-2 bg-secondary text-secondary-foreground rounded-lg hover:opacity-90 transition-all">
            Бронирование
          </button>
        </Link>
      )}
    </nav>
  );
}
