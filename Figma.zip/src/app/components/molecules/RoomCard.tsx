import { Link } from 'react-router';
import { Button } from '../atoms/Button';
import { Icons } from '../atoms/Icons';

interface RoomCardProps {
  id: string;
  title: string;
  price: number;
  capacity: number;
  image: string;
}

export function RoomCard({ id, title, price, capacity, image }: RoomCardProps) {
  return (
    <div className="bg-card rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-shadow duration-300">
      <img
        src={image}
        alt={title}
        className="w-full h-48 object-cover"
      />
      <div className="p-5">
        <h3 className="mb-2">{title}</h3>
        <div className="flex items-center gap-2 text-muted-foreground mb-3">
          <Icons.Users size={18} />
          <span className="text-sm">{capacity} гостя</span>
        </div>
        <div className="flex items-center justify-between">
          <div>
            <p className="text-2xl font-semibold text-primary">{price} ₽</p>
            <p className="text-sm text-muted-foreground">за ночь</p>
          </div>
          <Link to={`/room/${id}`}>
            <Button variant="outline">Подробнее</Button>
          </Link>
        </div>
      </div>
    </div>
  );
}
